SUPPLEMENTARY MATERIALS — 15 October 2026
Manuscript remotesensing-4601743

Supplementary_Analyses.pdf is the current 52-page Supplement, containing
Sections S1–S30, Tables S1–S41 and Figures S1–S15.

Numerical_Tables retains numerical results and supporting provenance records.
SUPPORT_SENSITIVITY contains paired-window, ocean-support and SAR point diagnostics.
VH_EXTENSION contains the additional −20, −22 and −24 dB threshold comparisons.
TEN_YEAR_BACKGROUND contains the calendar-matched 2016–2025 reference analyses,
source metadata and observation-support records reported in Section S30.
Earlier original-product background comparisons remain in Section S29.

Use the current PDF for final section, figure and table numbering. Area ranges
and map-agreement measures are descriptive parameter comparisons, not independent
accuracy estimates. Public reports provide location and timing context; field
reference boundaries were not acquired by this study. The current Supplement
states the limitations of the completed external-product comparisons.

Analysis scripts, selected arrays, numerical outputs, acquisition records and
three runnable offline examples are supplied separately in
Review_Support_Code_Data.zip. Follow README_REVIEW_SUPPORT.txt in that archive.
The editable Supplement and source figures are retained in the author's local
review directory. Scientific arrays, masks, thresholds and values are unchanged
by this final language and formatting audit.
