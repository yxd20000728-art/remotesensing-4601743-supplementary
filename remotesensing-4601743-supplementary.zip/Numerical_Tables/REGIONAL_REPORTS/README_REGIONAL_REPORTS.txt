Regional reports checked on 12 October 2026

regional_source_registry lists five additional public sources, their publication dates, observation/survey dates and evidential limits. University reports describe surveys conducted by other teams. Their underlying flood marks, coordinates, UAV orthophotos and reference labels were not acquired.

candidate_administrative_presence.csv reproduces retained native-grid candidate counts within GADM 4.1 boundaries from the previous local audit. These are administrative summaries of potential candidates, not verified flooded areas or village-level matches. They must not be used as ground truth, dry controls, calibration samples or IoU labels.

Detailed completed external flood-product comparisons remain in the Supplement and the support archive. The main text states the limited agreement. No scientific raster, threshold, area or numerical comparison was changed.
